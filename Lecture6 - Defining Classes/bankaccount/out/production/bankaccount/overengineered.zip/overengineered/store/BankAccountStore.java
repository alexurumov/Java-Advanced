package overengineered.store;

import overengineered.BankAccount;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class BankAccountStore {

    private static  Map<Integer, BankAccount> accounts;

    public static void initializeStore() {
        accounts = new HashMap<>();
    }

    public static Optional<BankAccount> getById(int id) {
        return Optional.of(accounts.get(id));
    }

    public static void save(BankAccount account) {
        accounts.put(account.getId(), account);
    }
}
