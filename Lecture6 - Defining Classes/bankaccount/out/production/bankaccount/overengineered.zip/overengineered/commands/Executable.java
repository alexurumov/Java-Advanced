package overengineered.commands;

interface Executable {

    void execute();

    String getOutput();
}
